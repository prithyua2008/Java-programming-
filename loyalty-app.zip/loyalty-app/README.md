# Loyalty CRM Backend (Spring Boot)

Run: `mvn spring-boot:run` (Java 17+, Maven). Server: http://localhost:8080

## Try it
```
# 1. Merchant records a Rs.2500 bill for customer 1 at merchant 1
curl -X POST localhost:8080/api/purchases -H "Content-Type: application/json" \
  -d '{"customerId":1,"merchantId":1,"amount":2500}'

# 2. Customer redeems reward 1 for a coupon
curl -X POST localhost:8080/api/redeem -H "Content-Type: application/json" \
  -d '{"customerId":1,"rewardId":1}'

# 3. Merchant validates the coupon code
curl -X POST localhost:8080/api/coupons/<CODE>/use

# 4. Broadcast an offer to all customers
curl -X POST localhost:8080/api/offers/broadcast -H "Content-Type: application/json" \
  -d '{"message":"Weekend special: double points!"}'

# 5. View notifications
curl localhost:8080/api/customers/1/notifications
```
