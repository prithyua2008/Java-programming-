package com.loyalty;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Purchase {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    public Long customerId;
    public Long merchantId;
    public double amount;
    public int pointsEarned;
    public LocalDateTime createdAt = LocalDateTime.now();
}
