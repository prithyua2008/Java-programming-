package com.loyalty;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataSeeder implements CommandLineRunner {
    private final CustomerRepo customers;
    private final MerchantRepo merchants;
    private final RewardRepo rewards;

    public DataSeeder(CustomerRepo c, MerchantRepo m, RewardRepo r) {
        this.customers = c; this.merchants = m; this.rewards = r;
    }

    @Override
    public void run(String... args) {
        customers.save(new Customer("Demo User", "9999999999"));
        merchants.save(new Merchant("Spice Garden Restaurant", "RESTAURANT", 10));
        merchants.save(new Merchant("Big Basket Supermart", "SUPERMARKET", 5));
        rewards.save(new Reward("10% off any bill", 100, 10));
        rewards.save(new Reward("20% off any bill", 250, 20));
    }
}
