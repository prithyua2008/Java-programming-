package com.loyalty;

import jakarta.persistence.*;

@Entity
public class Customer {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    public String name;
    @Column(unique = true)
    public String phone;
    public int points;
    public double lifetimeSpend;
    public String tier = "SILVER";

    public Customer() {}
    public Customer(String name, String phone) { this.name = name; this.phone = phone; }
}
