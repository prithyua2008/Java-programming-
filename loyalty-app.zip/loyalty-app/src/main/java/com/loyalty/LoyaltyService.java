package com.loyalty;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.util.UUID;

@Service
public class LoyaltyService {
    private final CustomerRepo customers;
    private final MerchantRepo merchants;
    private final PurchaseRepo purchases;
    private final RewardRepo rewards;
    private final CouponRepo coupons;
    private final NotificationRepo notifications;

    public LoyaltyService(CustomerRepo c, MerchantRepo m, PurchaseRepo p,
                          RewardRepo r, CouponRepo cp, NotificationRepo n) {
        this.customers = c; this.merchants = m; this.purchases = p;
        this.rewards = r; this.coupons = cp; this.notifications = n;
    }

    private ResponseStatusException notFound(String what) {
        return new ResponseStatusException(HttpStatus.NOT_FOUND, what + " not found");
    }

    private double tierMultiplier(String tier) {
        return switch (tier) {
            case "PLATINUM" -> 1.5;
            case "GOLD" -> 1.25;
            default -> 1.0;
        };
    }

    private String tierFor(double lifetimeSpend) {
        if (lifetimeSpend >= 20000) return "PLATINUM";
        if (lifetimeSpend >= 5000) return "GOLD";
        return "SILVER";
    }

    /** Merchant records a bill: customer earns points based on merchant rate and tier. */
    @Transactional
    public Purchase recordPurchase(Long customerId, Long merchantId, double amount) {
        if (amount <= 0) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Amount must be positive");
        Customer c = customers.findById(customerId).orElseThrow(() -> notFound("Customer"));
        Merchant m = merchants.findById(merchantId).orElseThrow(() -> notFound("Merchant"));

        int earned = (int) Math.floor(amount / 100.0 * m.earnRate * tierMultiplier(c.tier));
        c.points += earned;
        c.lifetimeSpend += amount;

        String oldTier = c.tier;
        c.tier = tierFor(c.lifetimeSpend);
        customers.save(c);

        Purchase p = new Purchase();
        p.customerId = customerId;
        p.merchantId = merchantId;
        p.amount = amount;
        p.pointsEarned = earned;
        purchases.save(p);

        notifications.save(new Notification(customerId,
                "You earned " + earned + " points at " + m.name + ". Balance: " + c.points));
        if (!oldTier.equals(c.tier)) {
            notifications.save(new Notification(customerId, "Congrats! You are now " + c.tier + " tier."));
        }
        return p;
    }

    /** Customer spends points to get a coupon. */
    @Transactional
    public Coupon redeemReward(Long customerId, Long rewardId) {
        Customer c = customers.findById(customerId).orElseThrow(() -> notFound("Customer"));
        Reward r = rewards.findById(rewardId).orElseThrow(() -> notFound("Reward"));
        if (c.points < r.pointsCost) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Not enough points");
        }
        c.points -= r.pointsCost;
        customers.save(c);

        Coupon cp = new Coupon();
        cp.code = UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        cp.customerId = customerId;
        cp.discountPercent = r.discountPercent;
        cp.expiresAt = LocalDate.now().plusDays(30);
        coupons.save(cp);

        notifications.save(new Notification(customerId,
                "Reward claimed: " + r.title + ". Coupon " + cp.code + " valid till " + cp.expiresAt));
        return cp;
    }

    /** Merchant validates a coupon at checkout; it can only be used once. */
    @Transactional
    public Coupon useCoupon(String code) {
        Coupon cp = coupons.findByCode(code).orElseThrow(() -> notFound("Coupon"));
        if (cp.used) throw new ResponseStatusException(HttpStatus.CONFLICT, "Coupon already used");
        if (cp.expiresAt.isBefore(LocalDate.now())) {
            throw new ResponseStatusException(HttpStatus.GONE, "Coupon expired");
        }
        cp.used = true;
        return coupons.save(cp);
    }

    /** Send an offer to every customer (swap this loop for FCM push in production). */
    @Transactional
    public int broadcastOffer(String message) {
        var all = customers.findAll();
        all.forEach(c -> notifications.save(new Notification(c.id, message)));
        return all.size();
    }
}
