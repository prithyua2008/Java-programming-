package com.loyalty;

import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class LoyaltyController {
    record PurchaseRequest(Long customerId, Long merchantId, double amount) {}
    record RedeemRequest(Long customerId, Long rewardId) {}
    record OfferRequest(String message) {}

    private final LoyaltyService service;
    private final CustomerRepo customers;
    private final MerchantRepo merchants;
    private final RewardRepo rewards;
    private final CouponRepo coupons;
    private final NotificationRepo notifications;

    public LoyaltyController(LoyaltyService s, CustomerRepo c, MerchantRepo m,
                             RewardRepo r, CouponRepo cp, NotificationRepo n) {
        this.service = s; this.customers = c; this.merchants = m;
        this.rewards = r; this.coupons = cp; this.notifications = n;
    }

    @PostMapping("/customers")
    public Customer register(@RequestBody Customer c) { return customers.save(new Customer(c.name, c.phone)); }

    @GetMapping("/customers/{id}")
    public Customer customer(@PathVariable Long id) { return customers.findById(id).orElseThrow(); }

    @GetMapping("/merchants")
    public List<Merchant> merchants() { return merchants.findAll(); }

    @GetMapping("/rewards")
    public List<Reward> rewards() { return rewards.findAll(); }

    @PostMapping("/purchases")
    public Purchase purchase(@RequestBody PurchaseRequest r) {
        return service.recordPurchase(r.customerId(), r.merchantId(), r.amount());
    }

    @PostMapping("/redeem")
    public Coupon redeem(@RequestBody RedeemRequest r) {
        return service.redeemReward(r.customerId(), r.rewardId());
    }

    @GetMapping("/customers/{id}/coupons")
    public List<Coupon> myCoupons(@PathVariable Long id) { return coupons.findByCustomerId(id); }

    @PostMapping("/coupons/{code}/use")
    public Coupon useCoupon(@PathVariable String code) { return service.useCoupon(code); }

    @GetMapping("/customers/{id}/notifications")
    public List<Notification> notifications(@PathVariable Long id) {
        return notifications.findByCustomerIdOrderByCreatedAtDesc(id);
    }

    @PostMapping("/offers/broadcast")
    public Map<String, Integer> broadcast(@RequestBody OfferRequest r) {
        return Map.of("sentTo", service.broadcastOffer(r.message()));
    }
}
