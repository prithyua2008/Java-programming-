package com.loyalty;

import jakarta.persistence.*;

@Entity
public class Reward {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    public String title;
    public int pointsCost;
    public int discountPercent;

    public Reward() {}
    public Reward(String title, int pointsCost, int discountPercent) {
        this.title = title; this.pointsCost = pointsCost; this.discountPercent = discountPercent;
    }
}
