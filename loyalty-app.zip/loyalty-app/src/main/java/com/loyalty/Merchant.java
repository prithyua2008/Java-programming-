package com.loyalty;

import jakarta.persistence.*;

@Entity
public class Merchant {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    public String name;
    public String type;          // RESTAURANT or SUPERMARKET
    public double earnRate;      // points per 100 spent

    public Merchant() {}
    public Merchant(String name, String type, double earnRate) {
        this.name = name; this.type = type; this.earnRate = earnRate;
    }
}
