package com.loyalty;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Notification {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    public Long customerId;
    public String message;
    public LocalDateTime createdAt = LocalDateTime.now();

    public Notification() {}
    public Notification(Long customerId, String message) {
        this.customerId = customerId; this.message = message;
    }
}
