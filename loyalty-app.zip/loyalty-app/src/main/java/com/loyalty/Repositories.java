package com.loyalty;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

interface CustomerRepo extends JpaRepository<Customer, Long> {
    Optional<Customer> findByPhone(String phone);
}
interface MerchantRepo extends JpaRepository<Merchant, Long> {}
interface PurchaseRepo extends JpaRepository<Purchase, Long> {
    List<Purchase> findByCustomerIdOrderByCreatedAtDesc(Long customerId);
}
interface RewardRepo extends JpaRepository<Reward, Long> {}
interface CouponRepo extends JpaRepository<Coupon, Long> {
    Optional<Coupon> findByCode(String code);
    List<Coupon> findByCustomerId(Long customerId);
}
interface NotificationRepo extends JpaRepository<Notification, Long> {
    List<Notification> findByCustomerIdOrderByCreatedAtDesc(Long customerId);
}
