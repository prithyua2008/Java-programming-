package com.loyalty;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
public class Coupon {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    @Column(unique = true)
    public String code;
    public Long customerId;
    public int discountPercent;
    public boolean used;
    public LocalDate expiresAt;
}
